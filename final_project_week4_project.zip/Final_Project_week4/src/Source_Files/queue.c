/*
 * queue.c
 *
 *  Created on: Mar 1, 2022
 *      Author: brucytao200121
 */

#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

struct node_t* create_queue(int data, int size) {
    // return null so it compiles
    struct node_t* head = create_new_node(data);            //assign a new node to head node once
    struct node_t* temp = head;                                 //assign the head node to the temporary node
    for(int i = 1; i < size; i++)
    {
        struct node_t* new_node = create_new_node(data);    //assign a new node to the new_node
        temp->next = new_node;                                  //link the temporary->next to the new_node
        temp = new_node;                                        //assign the new_node to be the temp node
    }
    return head;
}

struct node_t* create_new_node(int data) {
    // return null so it compiles
    struct node_t* nn = malloc(sizeof(struct node_t));
    nn->data = data;
    return nn;
}

int peek(struct node_t** head) {
    // return null so it compiles
    if(!is_empty(head))
    {
        return (*head)->data;
    }
}

void pop(struct node_t** head) {

      struct node_t* temp = *head;
      (*head) = (*head)->next;
      free(temp);
}

void push(struct node_t** head, int data) {
    struct node_t* ptr;
    ptr = create_new_node(data);
    ptr->data = data;
    ptr->next = NULL;
    if(*head == NULL)
      {
        *head = ptr;
      }
    else
      {
        struct node_t* temp = *head;
        while(temp->next != NULL)
          {
            temp = temp->next;
          }
        temp->next = ptr;
      }
}

int is_empty(struct node_t** head) {
    // return 0 so it compiles
    if(head == NULL)
    {
        return 1;
    }
    else{
        return 0;
    }

}

void empty_queue(struct node_t** head) {
    while(*head != NULL)
    {
        pop(head);
    }
}
