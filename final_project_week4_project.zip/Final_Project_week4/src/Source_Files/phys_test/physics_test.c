#include "physics.h"

#include <stdlib.h>
#include "ctest.h"

CTEST_DATA(x_direction) {
    int x_position;
    int delta_x;
};

CTEST_SETUP(x_direction) {
    data->x_position = 0;
    data->delta_x = 1;
    x_position(data->x_position, data->delta_x);
}

CTEST2(x_direction, test_process) {
        ASSERT_EQUAL(1, (int)data->x_position);
}


// CTEST_SETUP(x_direction) {
//     data->x_position = 128;
//     data->delta_x = 1;
//     x_position(data->x_position, data->delta_x);
// }

// CTEST2(x_direction, test_process) {
//         ASSERT_EQUAL(127, (int)data->x_position);
// }


// CTEST_DATA(x_direction) {
//     int y_position;
//     int delta_y;
// };

// CTEST_SETUP(x_direction) {
//     data->y_position = 0;
//     data->delta_y = 1;
//     x_position(data->y_position, data->delta_y);
// }

// CTEST2(x_direction, test_process) {
//         ASSERT_EQUAL(1, (int)data->y_position);
// }

// CTEST_SETUP(x_direction) {
//     data->y_position = 128;
//     data->delta_y = 1;
//     x_position(data->y_position, data->delta_y);
// }

// CTEST2(x_direction, test_process) {
//         ASSERT_EQUAL(127, (int)data->y_position);
// }