#include "physics.h"

int x_position(int x, int delt_x)
{
    int temp = x + delt_x;;
    if((temp) > 0 && (temp) < 128)
    {
        
        x = temp;
    }
    else if((temp) > 128 && (temp) < 2*128)     //bounce the right wall
    {
        x = 128 - delt_x;
    }
    else if((temp) > 2*128)                     //bounce the left wall
    {
        temp = 0;
        x = temp;
    }
    return x;
}