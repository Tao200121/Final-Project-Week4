/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

//#include "sl_simple_led.h"
//#include "sl_simple_led_instances.h"
#include "os.h"
#include "blink.h"
#include "em_emu.h"
#include "queue.h"
#include "glib.h"
#include "sl_board_control.h"
#include "sl_board_control_config.h"

/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/



//static OS_TCB tcb
static OS_TCB btn0_handler_tcb,
              btn1_handler_tcb,
              physics_task_tcb,
              idle_tcb,
              led_output_tcb,
              lcd_display_tcb,
              platform_tcb;

//static CPU_STK  stack[BLINK_TASK_STACK_SIZE]
static CPU_STK  button_stack[BUTTON_TASK_STACK_SIZE],
                physics_stack[PHYSICS_TASK_STACK_SIZE],
                idle_stack[IDLE_TASK_STACK_SIZE],
                led_output_stack[IDLE_TASK_STACK_SIZE],
                lcd_display_stack[LCD_DISPLAY_TASK_STACK_SIZE],
                platform_stack[platform_TASK_STACK_SIZE];


#define CHANNEL0  0
#define CHANNEL1  1
#define CHANNEL2  2
#define CHANNEL3  3



static OS_FLAG_GRP flag_grp1;    //flag group pointer
static OS_FLAG_GRP flag_grp2;

static OS_SEM btn0_semaphore,
              btn1_semaphore,
              ball_semaphore,
              energy_semaphore;        //semaphore pointer

static OS_Q msg_q;              //message queue pointer

static OS_TMR timer,
              btn_timer;            //timer pointer

static OS_MUTEX mutex1;
static OS_MUTEX ball_mutex;

static RTOS_ERR semaphore_err,
                msg_q_err,
                flag_grp_err,
                capsense_err;

static GLIB_Context_t ball;

static GLIB_Context_t speed_display;
static int topLine = 0;
static int second_line = 1;
char string[100];
char string2[100];
int current_speed;

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

//static void blink_task(void *arg);
static void btn0_handler_task(void *arg);
static void btn1_handler_task(void *arg)
static void idle_task(void *arg);
static void physics_task(void *arg);
static void lcd_display_task(void *arg);
static void led_display_task(void *arg);
static void platform_task(void *arg);
static void create(void);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize blink example.
 ******************************************************************************/

struct platform platform1;
struct ball ball1;
int make_turn = 0;
int previous_turn = 0;

static volatile uint32_t msTicks;

bool sense0;
bool sense1;
bool sense2;
bool sense3;
int slide_time;

int32_t delta_x, delta_y;
int32_t velocity_x, velocity_y;
int32_t velocity;
int32_t kinetic_e;
int32_t tao_physics;


//void SysTick_Handler(void)
//{
//
//}

//enum alert_event_flag{
//  alert_event_flag0 = 2,
//  alert_event_flag1 = 4,
//  alert_event_flag3 = 8,
//  alert_event_flag4 = 16,
//};

struct node_t* speed;
int speed_change;

void GPIO_EVEN_IRQHandler(void)
{
//TODO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  RTOS_ERR err;
  GPIO_IntClear(1 << BUTTON0_pin);
  OSSemPost(&btn0_semaphore, OS_OPT_POST_1, &err);

}

void GPIO_ODD_IRQHandler(void)
{
//TODO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  RTOS_ERR err;
  GPIO_IntClear(1 << BUTTON1_pin);
  OSSemPost(&btn1_semaphore, OS_OPT_POST_1, &err);

}

void blink_init(void)
{
  RTOS_ERR err;

  OSTaskCreate(&btn0_handler_tcb,
                 "button0 handler task",
                 btn0_handler_task,
                 DEF_NULL,
                 BUTTON_TASK_PRIO,
                 &button_stack[0],
                 (BUTTON_TASK_STACK_SIZE / 10u),
                 BUTTON_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

  OSTaskCreate(&btn1_handler_tcb,
                 "button1 handler task",
                 btn1_handler_task,
                 DEF_NULL,
                 BUTTON_TASK_PRIO,
                 &button_stack[0],
                 (BUTTON_TASK_STACK_SIZE / 10u),
                 BUTTON_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

  OSTaskCreate(&physics_task_tcb,
                 "physics task",
                 physics_task,
                 DEF_NULL,
                 PHYSICS_TASK_PRIO,
                 &physics_stack[0],
                 (PHYSICS_TASK_STACK_SIZE / 10u),
                 PHYSICS_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

  OSTaskCreate(&idle_tcb,
                 "idle task",
                 idle_task,
                 DEF_NULL,
                 IDLE_TASK_PRIO,
                 &idle_stack[0],
                 (IDLE_TASK_STACK_SIZE / 10u),
                 IDLE_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

  OSTaskCreate(&led_output_tcb,
                 "led_output task",
                 led_output_task,
                 DEF_NULL,
                 LED_OUTPUT_TASK_PRIO,
                 &led_output_stack[0],
                 (LED_OUTPUT_TASK_STACK_SIZE / 10u),
                 LED_OUTPUT_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

  OSTaskCreate(&lcd_display_tcb,
                 "lcd display task",
                 lcd_display_task,
                 DEF_NULL,
                 LCD_DISPLAY_TASK_PRIO,
                 &lcd_display_stack[0],
                 (LCD_DISPLAY_TASK_STACK_SIZE / 10u),
                 LCD_DISPLAY_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

  OSTaskCreate(&platform_tcb,
                 "platform task",
                 platform_task,
                 DEF_NULL,
                 platform_TASK_PRIO,
                 &platform_stack[0],
                 (platform_TASK_STACK_SIZE / 10u),
                 platform_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  create();
}



//timer callback function
void timer_callback(OS_TMR *timer, void *p_arg)
{
  PP_UNUSED_PARAM(timer);
  PP_UNUSED_PARAM(p_arg);
  OSSemPost(&btn0_semaphore, OS_OPT_POST_1, &semaphore_err);

}

void btn_timer_callback(OS_TMR *timer, void *p_arg)
{
  RTOS_ERR err;
  PP_UNUSED_PARAM(timer);
  PP_UNUSED_PARAM(p_arg);
  //original energy
}


//create timer
void create(void)
{
  RTOS_ERR err;
  //create message queue
  OSQCreate(&msg_q, "msg_q", MSG_Q_SIZE, &msg_q_err);

  //create semaphore
  OSSemCreate(&btn0_semaphore, "semaphore", 0, &semaphore_err);

  //create flag group
  OSFlagCreate(&flag_grp1, "flag_grp1", 0, &flag_grp_err);
  OSFlagCreate(&flag_grp2, "flag_grp2", 0, &flag_grp_err);

  //create timer
  OSTmrCreate(&timer, "timer", 0, 10, OS_OPT_TMR_PERIODIC, timer_callback, NULL, &err);
  OSTmrCreate(&btn_timer, "btn timer", 0, 10, OS_OPT_TMR_ONE_SHOT, btn_timer_callback, NULL, &err);


  //create mutex
  OSMutexCreate(&mutex1, "speed_setpoint_mutex", &err);
}


/***************************************************************************//**
 * button0 task.
 ******************************************************************************/


static void btn0_handler_task(void *arg)
{
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;
  while(1)
    {
      OSSemPend(&btn0_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &capsense_err);
      OSTmrStart(btn_timer, &err);
      //energize
      platform1.energy = 1;
    }

}


static void btn1_handler_task(void *arg)
{
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;
  while(1)
    {
      OSSemPend(&btn1_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &capsense_err);
      //call physics task
    }
  //wins automatically in this turn.
}


static void physics_task(void *arg)
{
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;
  OSMutexPend(&ball_mutex, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
  ball1.ball_x_position = 5;
  ball1.ball_y_position = 5;
  OSMutexPost(&ball_mutex, OS_OPT_POST_NONE, &err);
  OSSemPost(&ball_semaphore, OS_OPT_POST_1, &err);    //post a semaphore to the lcd
  while(1)
    {

      OSMutexPend(&ball_mutex, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
      ball1.ball_x_position = x_position(ball1.ball_x_position);

//      ball1.ball_y_position = y_position(ball1.ball_y_position);

      OSMutexPost(&ball_mutex, OS_OPT_POST_NONE, &err);
      OSSemPost(&ball_semaphore, OS_OPT_POST_1, &err);    //post a semaphore to the lcd

    }

}

int x_position(int x)
{
  delta_x = ball1.vx * tao_physics;
  x += delta_x;
  int temp;
    if(x <= 0)
    {
        ball1.vx = -1*ball1.vx;     //flip the velocity
        x = -x;
    }
    else if(x >= 128)
      {
        ball1.vx = -1*ball1.vx;
        temp = x - 128;
        x = 128 - temp;
      }

    return x;
}

int y_position(int y)
{
  if(y > 0 && y < 128)
    {
      delta_y = ball1.vy * tao_physics + 0.5 * gravity * tao_physics^2;
      ball1.vy += gravity * tao_physics
    }
  return y;
}


static void platform_task(void *arg)
{
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;
  while(1)
  {
  }
}

void read_capsense(void)
{

  CAPSENSE_Sense();
  RTOS_ERR err;
  sense0 = CAPSENSE_getPressed(CHANNEL0);
  sense1 = CAPSENSE_getPressed(CHANNEL1);
  sense2 = CAPSENSE_getPressed(CHANNEL2);
  sense3 = CAPSENSE_getPressed(CHANNEL3);

//  OSMutexPend(&mutex2, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
//
//  OSMutexPost(&mutex2, OS_OPT_POST_NONE, &err);
}

static void vehicle_direction_task(void *arg)
{
  PP_UNUSED_PARAM(arg);

  RTOS_ERR err;

  while (1)
  {
      read_capsense();


      OSTimeDly(10, OS_OPT_TIME_DLY, &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  }
}


static void vehicle_monitor_task(void *arg)
{
  PP_UNUSED_PARAM(arg);

  RTOS_ERR err;


  while(1)
    {
//      OSFlagPend(&flag_grp1,
//                 speed_update_flag + direction_update_flag,
//                 ZERO,
//                 OS_OPT_PEND_FLAG_SET_ANY + OS_OPT_PEND_FLAG_CONSUME,
//                 DEF_NULL,
//                 &err);
//      if(speed_setpoint.current_speed > 75)
//        {
//          OSFlagPost(&flag_grp2, alert_event_flag0, OS_OPT_POST_FLAG_SET, &err);
//        }
//      else if(speed_setpoint.current_speed > 45 && make_turn == 1)
//        {
//          OSFlagPost(&flag_grp2, alert_event_flag0, OS_OPT_POST_FLAG_SET, &err);
//        }
//      else if(vehicle_direction.current_direction == 1 && msTicks > 5000)
//        {
//          if(speed_setpoint.current_speed > 75)
//            {
//              OSFlagPost(&flag_grp2, alert_event_flag4, OS_OPT_POST_FLAG_SET, &err);
//            }
//          else{
//              OSFlagPost(&flag_grp2, alert_event_flag1, OS_OPT_POST_FLAG_SET, &err);
//          }
//
//        }
//      else if(vehicle_direction.current_direction == 2 && msTicks > 5000)
//        {
//          if(speed_setpoint.current_speed > 75)
//            {
//              OSFlagPost(&flag_grp2, alert_event_flag4, OS_OPT_POST_FLAG_SET, &err);
//            }
//          else
//            {
//              OSFlagPost(&flag_grp2, alert_event_flag1, OS_OPT_POST_FLAG_SET, &err);
//            }
//
//        }
//      else if(vehicle_direction.current_direction == 3 && msTicks > 5000)
//        {
//          if(speed_setpoint.current_speed > 75)
//            {
//              OSFlagPost(&flag_grp2, alert_event_flag4, OS_OPT_POST_FLAG_SET, &err);
//            }
//          else
//            {
//              OSFlagPost(&flag_grp2, alert_event_flag1, OS_OPT_POST_FLAG_SET, &err);
//            }
//
//        }
//      else if(vehicle_direction.current_direction == 4 && msTicks > 5000)
//        {
//          if(speed_setpoint.current_speed > 75)
//            {
//              OSFlagPost(&flag_grp2, alert_event_flag4, OS_OPT_POST_FLAG_SET, &err);
//            }
//          else
//            {
//              OSFlagPost(&flag_grp2, alert_event_flag1, OS_OPT_POST_FLAG_SET, &err);
//            }
//
//        }
//      else
//        {
//          OSFlagPost(&flag_grp2, alert_event_flag3, OS_OPT_POST_FLAG_SET, &err);
//        }
    }




  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}




static void led_output_task(void *arg)
{
  PP_UNUSED_PARAM(arg);

  RTOS_ERR err;
  int result;
  int button0_pressed = 0;
  int button1_pressed = 0;
  while(1)
    {
      result = OSFlagPend(&flag_grp2,
                           alert_event_flag0 + alert_event_flag1 + alert_event_flag3 + alert_event_flag4,
                           ZERO,
                           OS_OPT_PEND_FLAG_SET_ANY + OS_OPT_PEND_FLAG_CONSUME,
                           DEF_NULL,
                           &err);
       if(result == alert_event_flag0)    //release all buttons
         {
           GPIO_PinOutSet(LED0_port, LED0_pin);
           GPIO_PinOutClear(LED1_port, LED1_pin);
         }
       else if(result == alert_event_flag1)
         {
           GPIO_PinOutClear(LED0_port, LED0_pin);
           GPIO_PinOutSet(LED1_port, LED1_pin);
         }
       else if(result == alert_event_flag4)
         {
           GPIO_PinOutSet(LED0_port, LED0_pin);
           GPIO_PinOutSet(LED1_port, LED1_pin);
         }
       else if(result == alert_event_flag3)
         {
           GPIO_PinOutClear(LED0_port, LED0_pin);
           GPIO_PinOutClear(LED1_port, LED1_pin);
         }
    }

      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}


static void lcd_display_task(void *arg)
{
  PP_UNUSED_PARAM(arg);

  RTOS_ERR err;
  uint32_t status;

  /* Enable the memory lcd */
  status = sl_board_enable_display();
  EFM_ASSERT(status == SL_STATUS_OK);

  /* Initialize the DMD support for memory lcd display */
  status = DMD_init(0);
  EFM_ASSERT(status == DMD_OK);

  /* Initialize the glib context */
  status = GLIB_contextInit(&speed_display);
  EFM_ASSERT(status == GLIB_OK);

  speed_display.backgroundColor = White;
  speed_display.foregroundColor = Black;

  /* Fill lcd with background color */
  GLIB_clear(&speed_display);

  /* Use Narrow font */
  GLIB_setFont(&speed_display, (GLIB_Font_t *) &GLIB_FontNarrow6x8);



  while(1){
      //speed
      OSSemPend(&ball_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
      OSMutexPend(&mutex1, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);

        OSMutexPost(&mutex1, OS_OPT_POST_NONE, &err);


        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        //direction
        OSMutexPend(&ball_mutex, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);

        OSMutexPost(&ball_mutex, OS_OPT_POST_NONE, &err);

        OSTimeDly(10, OS_OPT_TIME_DLY, &err);
  }
}




static void idle_task(void *arg)
{
  PP_UNUSED_PARAM(arg);

  RTOS_ERR err;
  while (1)
  {
      EMU_EnterEM1();
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  }
}
